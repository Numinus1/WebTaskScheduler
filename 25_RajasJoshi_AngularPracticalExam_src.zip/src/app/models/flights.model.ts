export class Flights {
	constructor(){
		this.triptype = '';
		this.from = '';
        this.destination = '';
        this.departure = '';
        this.return = '';
        this.adults = '';
        this.children = '';
        this.infants = '';
	}
	public triptype;
	public from;
    public destination;
    public departure;
    public return;
    public adults;
    public children;
    public infants;
}